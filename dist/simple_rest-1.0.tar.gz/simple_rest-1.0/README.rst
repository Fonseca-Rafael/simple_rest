 simple rest
 -----------

 how to use::
 export SIMPLE_REST_INPUT=<dictionary filename>
 >>> import simple_rest
 >>> simple_rest.run()
